<template>
  <div class="bitovi-module-wrapper">
    <div class="bitovi-module articles-featured-module"></div>
  </div>
</template>
